﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class TrailController : MonoBehaviour
{
    private const int FRAME_MAX = 10;
    private List<Vector3> Points0 = new List<Vector3>();// 根本
    private List<Vector3> Points1 = new List<Vector3>();// 先端

    private Mesh mesh;

    void Start ()
    {
        mesh = GetComponent<MeshFilter>().mesh;
    }
	
	void Update ()
    {
		if(FRAME_MAX　<=　Points0.Count)
        {
            Points0.RemoveAt(0);
            Points1.RemoveAt(0);
        }

        Points0.Add(transform.position);
        Points1.Add(transform.TransformPoint(new Vector3(0.0f, 1.0f, 0.0f)));

        if(2　<=　Points0.Count)// エッジ一つでは帯は作れない
        {
            CreateMesh();
        }
    }

    private void CreateMesh()
    {
        mesh.Clear(); // メッシュのクリア

        // メモリ確保
        int n = Points0.Count;
        Vector3[] vertexArray = new Vector3[2 * n];
        Vector2[] uvArray = new Vector2[2 * n];
        int[] indexArray = new int[6 * (n - 1)];

        int idV = 0, idI = 0;
        float dUv = 1.0f / ((float)n - 1.0f);
        for(int i = 0; i < n; i++)
        {
            // 頂点座標
            vertexArray[idV + 0] = transform.InverseTransformPoint(Points0[i]);
            vertexArray[idV + 1] = transform.InverseTransformPoint(Points1[i]);
            // UV座標
            uvArray[idV + 0].x = 0.0f;
            uvArray[idV + 1].x = 1.0f - dUv * (float)i;
            uvArray[idV + 0].y = 0.0f;
            uvArray[idV + 1].y = 1.0f;

            // インデックス
            if (i == n - 1) break;// 最後の辺では帯を作らない
            indexArray[idI + 0] = idV;
            indexArray[idI + 1] = idV + 1;
            indexArray[idI + 2] = idV + 2;
            indexArray[idI + 3] = idV + 2;
            indexArray[idI + 4] = idV + 1;
            indexArray[idI + 5] = idV + 3;

            idV += 2;
            idI += 6;
        }

        mesh.vertices = vertexArray;
        mesh.uv = uvArray;
        mesh.triangles = indexArray;

        mesh.RecalculateBounds();
        mesh.RecalculateNormals();
    }
}