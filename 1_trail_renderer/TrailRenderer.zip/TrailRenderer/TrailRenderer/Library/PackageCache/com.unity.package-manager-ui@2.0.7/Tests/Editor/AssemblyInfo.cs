using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.PackageManagerCaptain.Editor")]
